function DynamixelMove(COM, ID, ang, model)
% Move Dynamixel
% 
% Two Dynamixels is tested: AX-12+ & MX-28AT
% 

%% Open serial port
delete(instrfindall)
s = serialport(COM, 115200);
configureTerminator(s,"CR");


%% Select Dynamixel:
% AX-12
if model == 1
    angle = (1023*ang) / 300; 
    angle = cast(angle, 'uint16');
% MX-28
elseif model == 2
    angle = (4095*ang) / 360;
    angle = cast(angle, 'uint16');
end


%% Send data - Protocol 1
% Convert angle into 2 Byte data
data	= [0x00, 0x00];         % 2 Byte angle data
data(1) = bitand(angle,0x00FF);	% MSB
data(2) = bitshift(angle, -8);	% LSB

% Packet
Header	= [0xFF 0xFF]; 
%ID     = ID;           % Dynamixel id
Length	= 0x05;         % Length of parameter + 2(chksum, inst)
Inst	= 0x03;         % Instruction, 0x03 is Write, 0x02 is Read, 0x01 is Ping(Status Packet Return)
P1      = 0x1E;         % Control table에서 특정 주소에 접근. 30은 Goal Position
P2      = data(1); 
P3      = data(2);

addall	= sum([ID Length Inst P1 P2 P3]);   %chksum을 위해 합치기
CKSM	= bitand(addall, 0x00ff);	%hex코드 하나짜리만을 남기기 위해 자름
CKSM	= cast(CKSM, 'uint8');    	%위 과정에서 uint16이 되니 uint8로 형변환
CKSM	= bitcmp(CKSM);             %bitwise complement. ~를 쓰면 안됨.
    
TxBuf   = [Header ID Length Inst P1 P2 P3 CKSM];
write(s, TxBuf, "uint8");

end





  
